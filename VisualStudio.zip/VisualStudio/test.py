import psycopg2

def table():
    conn = psycopg2.connect(dbname="postgres",user="postgres",password="Service1",host="localhost",port="5432")

    cursor = conn.cursor()

    cursor.execute('''create table employees(Name text, ID int, Age int);''')
    print('Table created successfully')

    conn.commit()
    conn.close()

def data():
    conn = psycopg2.connect(dbname="postgres",user="postgres",password="Service1",host="localhost",port="5432")

    cursor = conn.cursor()

    name = input("Enter Name: ")
    id = input("Enter Id: ")
    age= input("Enter age: ")

    query = '''INSERT INTO employees(Name, ID, Age) VALUES(%s,%s,%s);'''
    cursor.execute(query,(name,id,age))

    print('Data add successfully')

    conn.commit()
    conn.close()

data()

# def extract():
#     conn = psycopg2.connect(dbname="postgres",user="postgres",password="Service1",host="localhost",port="5432")

#     cursor = conn.cursor()

#     cursor.execute('''Select * from employees;''')
#     show = cursor.fetchone()
#     print(show[2])

#     conn.commit()
#     conn.close()

#extract()

